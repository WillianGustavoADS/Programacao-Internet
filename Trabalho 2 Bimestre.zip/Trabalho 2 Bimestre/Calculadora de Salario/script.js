
const percentuaisAumento = {
    "gerente": 0.10,   
    "engenheiro": 0.20, 
    "tecnico": 0.30     
};
const percentualPadrao = 0.40; 

const salarioAntigoInput = document.getElementById('salarioAntigo');
const cargoFuncionarioSelect = document.getElementById('cargoFuncionario');
const calcularBtn = document.getElementById('calcularBtn');
const salarioAntigoExibido = document.getElementById('salarioAntigoExibido');
const novoSalarioExibido = document.getElementById('novoSalarioExibido');
const diferencaSalarioExibido = document.getElementById('diferencaSalarioExibido');

function formatarMoeda(valor) {
    return `R$ ${valor.toFixed(2).replace('.', ',')}`;
}

function calcularNovoSalario() {
    const salarioAtual = parseFloat(salarioAntigoInput.value);
    const cargoSelecionado = cargoFuncionarioSelect.value;

    if (isNaN(salarioAtual) || salarioAtual <= 0) {
        alert("Por favor, insira um salário válido e positivo.");
    
        salarioAntigoExibido.textContent = formatarMoeda(0);
        novoSalarioExibido.textContent = formatarMoeda(0);
        diferencaSalarioExibido.textContent = formatarMoeda(0);
        return; 
    }

    if (cargoSelecionado === "") {
        alert("Por favor, selecione o cargo do funcionário.");
        
        salarioAntigoExibido.textContent = formatarMoeda(0);
        novoSalarioExibido.textContent = formatarMoeda(0);
        diferencaSalarioExibido.textContent = formatarMoeda(0);
        return; 
    }

    let percentualAplicado;
    
    if (percentuaisAumento.hasOwnProperty(cargoSelecionado)) {
        percentualAplicado = percentuaisAumento[cargoSelecionado];
    } else {
        
        percentualAplicado = percentualPadrao;
    }

    
    const valorAumento = salarioAtual * percentualAplicado;
    const novoSalario = salarioAtual + valorAumento;
    const diferenca = novoSalario - salarioAtual;

    
    salarioAntigoExibido.textContent = formatarMoeda(salarioAtual);
    novoSalarioExibido.textContent = formatarMoeda(novoSalario);
    diferencaSalarioExibido.textContent = formatarMoeda(diferenca);
}

calcularBtn.addEventListener('click', calcularNovoSalario);

salarioAntigoInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularNovoSalario();
    }
});