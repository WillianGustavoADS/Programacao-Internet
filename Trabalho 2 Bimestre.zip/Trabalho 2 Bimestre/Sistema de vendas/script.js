
const precoEtiquetaInput = document.getElementById('precoEtiqueta');
const condicaoPagamentoSelect = document.getElementById('condicaoPagamento');
const calcularBtn = document.getElementById('calcularBtn');
const precoEtiquetaExibido = document.getElementById('precoEtiquetaExibido');
const valorFinalExibido = document.getElementById('valorFinalExibido');
const diferencaValorExibido = document.getElementById('diferencaValorExibido');

function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor);
}

function calcularValorAPagar() {
    const precoOriginal = parseFloat(precoEtiquetaInput.value);
    const condicao = condicaoPagamentoSelect.value;

    
    if (isNaN(precoOriginal) || precoOriginal <= 0) {
        alert("Por favor, insira um preço de etiqueta válido e positivo.");
        
        precoEtiquetaExibido.textContent = formatarMoeda(0);
        valorFinalExibido.textContent = formatarMoeda(0);
        diferencaValorExibido.textContent = formatarMoeda(0);
        return;
    }

    if (condicao === "") {
        alert("Por favor, selecione uma condição de pagamento.");
      
        precoEtiquetaExibido.textContent = formatarMoeda(0);
        valorFinalExibido.textContent = formatarMoeda(0);
        diferencaValorExibido.textContent = formatarMoeda(0);
        return;
    }

    let valorFinal = precoOriginal;
    let diferenca = 0; 

    switch (condicao) {
        case 'a': 
            valorFinal = precoOriginal * 0.90; 
            diferenca = precoOriginal - valorFinal;
            diferencaValorExibido.style.color = '#28a745'; 
            break;
        case 'b': 
            valorFinal = precoOriginal * 0.85; 
            diferenca = precoOriginal - valorFinal;
            diferencaValorExibido.style.color = '#28a745'; 
            break;
        case 'c': 
            valorFinal = precoOriginal;
            diferenca = 0;
            diferencaValorExibido.style.color = '#555'; 
            break;
        case 'd': 
            valorFinal = precoOriginal * 1.10; 
            diferenca = valorFinal - precoOriginal;
            diferencaValorExibido.style.color = '#dc3545'; 
            break;
        default:
            
            alert("Condição de pagamento inválida.");
            valorFinalExibido.textContent = formatarMoeda(0);
            return;
    }

    precoEtiquetaExibido.textContent = formatarMoeda(precoOriginal);
    valorFinalExibido.textContent = formatarMoeda(valorFinal);

    if (diferenca > 0) {
        if (condicao === 'a' || condicao === 'b') {
            diferencaValorExibido.textContent = `Desconto: ${formatarMoeda(diferenca)}`;
        } else { 
            diferencaValorExibido.textContent = `Juros: ${formatarMoeda(diferenca)}`;
        }
    } else {
        diferencaValorExibido.textContent = "Nenhum desconto/juros";
        diferencaValorExibido.style.color = '#555'; 
    }
}

calcularBtn.addEventListener('click', calcularValorAPagar);

precoEtiquetaInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularValorAPagar();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    precoEtiquetaExibido.textContent = formatarMoeda(0);
    valorFinalExibido.textContent = formatarMoeda(0);
    diferencaValorExibido.textContent = formatarMoeda(0);
});