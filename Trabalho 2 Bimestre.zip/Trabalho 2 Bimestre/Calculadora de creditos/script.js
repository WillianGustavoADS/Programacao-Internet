
const saldoMedioInput = document.getElementById('saldoMedio');
const calcularBtn = document.getElementById('calcularBtn');
const saldoMedioExibido = document.getElementById('saldoMedioExibido');
const valorCreditoExibido = document.getElementById('valorCreditoExibido');


function formatarMoeda(valor) {
    
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor);
}

function calcularCredito() {
    const saldoMedio = parseFloat(saldoMedioInput.value);

    
    if (isNaN(saldoMedio) || saldoMedio < 0) {
        alert("Por favor, insira um saldo médio válido e não negativo.");
        
        saldoMedioExibido.textContent = formatarMoeda(0);
        valorCreditoExibido.textContent = formatarMoeda(0);
        return; 
    }

    let percentualCredito = 0; 
    let mensagemCredito = "Nenhum crédito especial.";

    if (saldoMedio > 600) {
        percentualCredito = 0.40; 
    } else if (saldoMedio >= 401) { 
        percentualCredito = 0.30; 
    } else if (saldoMedio >= 201) { 
        percentualCredito = 0.20; 
    }

    const valorCredito = saldoMedio * percentualCredito;

    saldoMedioExibido.textContent = formatarMoeda(saldoMedio);
    valorCreditoExibido.textContent = formatarMoeda(valorCredito);
}

calcularBtn.addEventListener('click', calcularCredito);

saldoMedioInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularCredito();
    }
});