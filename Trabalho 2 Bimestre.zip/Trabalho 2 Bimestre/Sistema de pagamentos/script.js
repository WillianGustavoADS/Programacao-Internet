
const valorHoraAulaPorNivel = {
    "1": 12.00, 
    "2": 17.00, 
    "3": 25.00  
};


const nivelProfessorSelect = document.getElementById('nivelProfessor');
const horasAulaInput = document.getElementById('horasAula');
const calcularBtn = document.getElementById('calcularBtn');
const valorHoraAulaExibido = document.getElementById('valorHoraAulaExibido');
const salarioExibido = document.getElementById('salarioExibido');

function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor);
}

function calcularSalarioProfessor() {
    const nivel = nivelProfessorSelect.value;
    const qtdHorasAula = parseInt(horasAulaInput.value);

    if (nivel === "") {
        alert("Por favor, selecione o nível do professor.");
        valorHoraAulaExibido.textContent = formatarMoeda(0);
        salarioExibido.textContent = formatarMoeda(0);
        return;
    }

    if (isNaN(qtdHorasAula) || qtdHorasAula < 0) {
        alert("Por favor, insira uma quantidade de horas/aula válida e não negativa.");
        valorHoraAulaExibido.textContent = formatarMoeda(0);
        salarioExibido.textContent = formatarMoeda(0);
        return;
    }

    const valorHoraAula = valorHoraAulaPorNivel[nivel];

    const salario = valorHoraAula * qtdHorasAula * 4.5;

    
    valorHoraAulaExibido.textContent = formatarMoeda(valorHoraAula);
    salarioExibido.textContent = formatarMoeda(salario);
}

calcularBtn.addEventListener('click', calcularSalarioProfessor);

horasAulaInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularSalarioProfessor();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    valorHoraAulaExibido.textContent = formatarMoeda(0);
    salarioExibido.textContent = formatarMoeda(0);
});