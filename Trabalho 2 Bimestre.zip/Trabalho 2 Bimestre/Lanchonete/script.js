
const cardapio = {
    100: { nome: "Cachorro Quente", preco: 11.00 },
    101: { nome: "Bauru", preco: 8.50 },
    102: { nome: "Misto Quente", preco: 8.00 },
    103: { nome: "Hambúrguer", preco: 9.00 },
    104: { nome: "Cheeseburger", preco: 10.00 },
    105: { nome: "Refrigerante", preco: 4.50 }
};

const codigoItemInput = document.getElementById('codigoItem');
const quantidadeInput = document.getElementById('quantidade');
const calcularBtn = document.getElementById('calcularBtn');
const nomeItemExibido = document.getElementById('nomeItemExibido');
const valorTotalExibido = document.getElementById('valorTotalExibido');

function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor);
}

function calcularValorLanche() {
    const codigo = parseInt(codigoItemInput.value);
    const quantidade = parseInt(quantidadeInput.value);

    if (isNaN(codigo) || !cardapio[codigo]) {
        alert("Por favor, insira um Código de Item válido conforme o cardápio.");
        nomeItemExibido.textContent = "---";
        valorTotalExibido.textContent = formatarMoeda(0);
        return;
    }

    if (isNaN(quantidade) || quantidade <= 0) {
        alert("Por favor, insira uma Quantidade válida (maior que zero).");
        nomeItemExibido.textContent = "---";
        valorTotalExibido.textContent = formatarMoeda(0);
        return;
    }

    const itemSelecionado = cardapio[codigo];

    const valorTotal = itemSelecionado.preco * quantidade;

    nomeItemExibido.textContent = itemSelecionado.nome;
    valorTotalExibido.textContent = formatarMoeda(valorTotal);
}

calcularBtn.addEventListener('click', calcularValorLanche);

codigoItemInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularValorLanche();
    }
});

quantidadeInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularValorLanche();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    nomeItemExibido.textContent = "---";
    valorTotalExibido.textContent = formatarMoeda(0);
});