
const pesoInput = document.getElementById('peso');
const alturaInput = document.getElementById('altura');
const calcularBtn = document.getElementById('calcularBtn');
const resultadoIMCDiv = document.getElementById('resultadoIMC');
const classificacaoIMCDiv = document.getElementById('classificacaoIMC');


function calcularIMC() {
    
    const peso = parseFloat(pesoInput.value);
    const altura = parseFloat(alturaInput.value);

    
    if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
        resultadoIMCDiv.textContent = "Por favor, insira valores válidos para peso e altura.";
        classificacaoIMCDiv.textContent = "";
        return; 
    }

    const imc = peso / (altura * altura);
    const imcArredondado = imc.toFixed(2); 

    let classificacao = "";
    if (imc < 18.5) {
        classificacao = "Abaixo do peso";
    } else if (imc >= 18.5 && imc <= 24.9) {
        classificacao = "Peso normal";
    } else if (imc >= 25 && imc <= 29.9) {
        classificacao = "Sobrepeso";
    } else if (imc >= 30 && imc <= 34.9) {
        classificacao = "Obesidade grau 1";
    } else if (imc >= 35 && imc <= 39.9) {
        classificacao = "Obesidade grau 2";
    } else { // imc >= 40
        classificacao = "Obesidade grau 3";
    }

    resultadoIMCDiv.textContent = `Seu IMC é: ${imcArredondado}`;
    classificacaoIMCDiv.textContent = `Classificação: ${classificacao}`;
}

calcularBtn.addEventListener('click', calcularIMC);


pesoInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularIMC();
    }
});
alturaInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularIMC();
    }
});