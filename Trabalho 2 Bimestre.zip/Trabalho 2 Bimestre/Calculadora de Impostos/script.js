
const anoFabricacaoInput = document.getElementById('anoFabricacao');
const valorTabelaInput = document.getElementById('valorTabela');
const calcularBtn = document.getElementById('calcularBtn');
const resultadoImpostoDiv = document.getElementById('resultadoImposto');


function calcularImpostoDETRAN() {
    
    const anoFabricacao = parseInt(anoFabricacaoInput.value);
    const valorTabela = parseFloat(valorTabelaInput.value);

    if (isNaN(anoFabricacao) || isNaN(valorTabela) || anoFabricacao <= 0 || valorTabela <= 0) {
        resultadoImpostoDiv.textContent = "Por favor, insira valores válidos e positivos para o ano e o valor de tabela.";
        return; 
    }

    let taxa;
    
    if (anoFabricacao < 1990) {
        taxa = 0.01; 
    } else {
        taxa = 0.015; 
    }

    const imposto = valorTabela * taxa;

    resultadoImpostoDiv.textContent = `O imposto a ser pago é: R$ ${imposto.toFixed(2).replace('.', ',')}`;
}

calcularBtn.addEventListener('click', calcularImpostoDETRAN);

anoFabricacaoInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularImpostoDETRAN();
    }
});
valorTabelaInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        calcularImpostoDETRAN();
    }
});