const ladoXInput = document.getElementById('ladoX');
const ladoYInput = document.getElementById('ladoY');
const ladoZInput = document.getElementById('ladoZ');
const verificarBtn = document.getElementById('verificarBtn');
const resultadoDiv = document.getElementById('resultado');

function verificarTriangulo(x, y, z) {
    if (typeof x !== 'number' || typeof y !== 'number' || typeof z !== 'number' ||
        x <= 0 || y <= 0 || z <= 0) {
        return "Por favor, insira valores numéricos positivos para os lados do triângulo.";
    }

    if (x < y + z && y < x + z && z < x + y) {
        if (x === y && y === z) {
            return "É um triângulo Equilátero.";
        } else if (x === y || x === z || y === z) {
            return "É um triângulo Isósceles.";
        } else {
            return "É um triângulo Escaleno.";
        }
    } else {
        return "Não é um triângulo.";
    }
}


verificarBtn.addEventListener('click', () => {
   
    const x = parseFloat(ladoXInput.value);
    const y = parseFloat(ladoYInput.value);
    const z = parseFloat(ladoZInput.value);

    const mensagem = verificarTriangulo(x, y, z);

    resultadoDiv.textContent = mensagem;
});